package hello2.hello.Spring2.service;

import hello2.hello.Spring2.domain.Member;
import hello2.hello.Spring2.repository.MemoryMemberRepository;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

//shft+F10 이전 build 그대로 실행
class MemberServiceTest {
    MemberService memberService;
    MemoryMemberRepository memberRepository;

   @BeforeEach
   public  void beforeEach(){
       memberRepository = new MemoryMemberRepository();
       memberService = new MemberService(memberRepository);

   }
    @AfterEach       /*메소드 동작이 끝날때마다 실행시켜주는 콜백 메소드*/
    public  void afterEach(){
        memberRepository.clearStore();
    }

    @Test
    void 회원가입() {
        //given 상황이 주어지고 (Test case 기본 문법)
        Member member = new Member();
        member.setName("spring");
        //when 무언가를 실행했을때(join 메소드 실행)
        Long saveId = memberService.join(member);

        //then 이러한 결과가 도출 맞는지 확인
        Member member1 = memberService.findOne(saveId).get();
        Assertions.assertThat(member.getName())
                .isEqualTo(member1.getName());
    }
/* Test case는 정상 케이스보다 예외 케이스가 더 중요!
* */
    @Test
    public void 중복_회원_예외(){
        //given
        Member member1 = new Member();
        member1.setName("spring");

        Member member2 = new Member();
        member2.setName("spring");
        //when
        memberService.join(member1);
        Assertions.assertThatThrownBy(() -> memberService.join(member2));


        /*try {
            memberService.join(member2);
            fail();
        }
        catch (IllegalStateException e ){
            Assertions.assertThat(e.getMessage()).isEqualTo("이미 존재하는 회원입니다.");
        }*/

        //then
    }

    @Test
    void findMembers() {
    }

    @Test
    void findOne() {
    }
}