package hello2.hello.Spring2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloSpring2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
