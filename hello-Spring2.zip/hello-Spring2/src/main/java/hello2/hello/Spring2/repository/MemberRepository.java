package hello2.hello.Spring2.repository;

import hello2.hello.Spring2.domain.Member;

import java.util.List;
import java.util.Optional;

/*회원객체를 저장하는 저장소*/
public interface MemberRepository {
    Member save (Member member);
    /*반환할 값이 없을때(Null 값), Optional이라는 값을 덮어씌워서 반환*/
    Optional<Member> findById(Long id);
    Optional<Member> findByName(String name);
    List<Member> findAll();
}
