package hello2.hello.Spring2.controller;

public class MemberForm {
    public String getName() {
        return name;
    }
    /*createMemberForm.html에서의 name과 매칭됨*/
    public void setName(String name) {
        this.name = name;
    }

    private String name;


}
