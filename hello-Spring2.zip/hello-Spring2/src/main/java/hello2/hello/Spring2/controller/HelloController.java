package hello2.hello.Spring2.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class HelloController {
    @GetMapping("hello")
    public String hello(Model model){
        model.addAttribute("data", "hello!!");
        return "hello";
    }


    @GetMapping("hello-mvc") //html 파일 불러올때 /hello-mvc를 사용해서 웹페이지를 불러 올 수 있음.
    public String helloMvc(@RequestParam("name")String name, Model model){
        model.addAttribute("name", name); // key값이 name
        return "hello-template";
    }
    // localhost:8080/hello-mvc?name= Spring!
    //두번째 parameter name에 Spring!!이 담김
    //MVC방식 View는 html파일을 이용해서 보여줌 (안드로이드 스튜디오에서 한것과같이
    //viewResolver= template를 찾아주고, view와 연결을 시켜주는 역할을 함
    //thymeleaf 템플릿 엔진이 html를 볼 수 있게 변환 후 웹 브라우저에 보이게 함


    @GetMapping("hello-string")
    @ResponseBody       //Json으로 반환하는게 default
    //이 annoatation을 사용하지 않으면, viewResolver를 활용해서 템플릿 view를 사용함
   /* http중 헤더부분과 바디부분 중 바디부분에 이 data를 직접 넣어주겠다라는 의미의 태그*/
    public String helloString(@RequestParam("name")String name){
        return "hello "+ name; //템플릿 view를 이용해서
        // 출력하는 것이 아닌 이 문자 그대로 출력
    }
/*    Json = Key(name) : value(spring!)로 이루어져있다.*/
    @GetMapping("hello-api")
    @ResponseBody
    /*이 annotation을 사용하면, HttpMessageConverter가 작동
    문자 -> StringConvert er / 객체 -> JsonConverter
    이렇게 객체를 반환하는 것이 API방식*/
    public Hello helloApi(@RequestParam("name") String name){
        Hello hello = new Hello();
        hello.setName(name);
        return hello;


    }
    static class Hello{
        private String name;
        public void setName(String name) {
            this.name = name;
        }
        public String getName() {
            return name;
        }
    }
}
