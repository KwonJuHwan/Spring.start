package hello2.hello.Spring2.service;

import hello2.hello.Spring2.domain.Member;
import hello2.hello.Spring2.repository.MemberRepository;
import hello2.hello.Spring2.repository.MemoryMemberRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
//Service class는 비즈니스에 가까운 용어를 사용해야한다.(roll에 맞는 naming)
@Transactional
public class MemberService {
    private final MemberRepository memberRepository;

    public MemberService(MemberRepository memberRepository) {
        this.memberRepository = memberRepository;
    }

    /*
    * 회원가입*/
    public Long join(Member member){
        //같은 이름이 있는 중복 회원은 안된다

        validateDuplicateMember(member);//중복회원 검증

        memberRepository.save(member);
        return member.getId();

    }

    private void validateDuplicateMember(Member member) {
        memberRepository.findByName(member.getName())
                .ifPresent(m -> {
            throw new IllegalStateException("이미 존재하는 회원입니다.");
        }); /*ifPresent= 값이 존재하면*/
        //method로 만들기 ctrl+art+M
        //값 반환하기 ctrl art  v
    }
/*전체 회원조회*/
    public List<Member> findMembers(){
        return memberRepository.findAll();
    }

    public Optional<Member> findOne(Long id){
        return memberRepository.findById(id);
    }
}
