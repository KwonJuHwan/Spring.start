package hello2.hello.Spring2.repository;

import hello2.hello.Spring2.domain.Member;
import org.springframework.stereotype.Repository;

import java.util.*;

public class MemoryMemberRepository implements MemberRepository{
    private static Map<Long, Member> store = new HashMap<>();
    /* 0,1,2와 같은 sequence값 생성을 위해서 */
    private static  long sequence = 0L;


    @Override
    public Member save(Member member) {
        member.setId(++sequence);   //id 세팅
        store.put(member.getId(), member);
        return member;
    }

    @Override
    public Optional<Member> findById(Long id) {
        return Optional.ofNullable(store.get(id));

    }

    @Override
    public Optional<Member> findByName(String name) {
        return store.values().stream(). //stream = loop돌기
                filter(member -> member.getName().equals(name)).findAny();
        //name과 같은 name이 있는 value가 있으면 바로 반환.
        // .values() = map에 있는 멤버들
    }

    @Override
    public List<Member> findAll() {
        return new ArrayList<>(store.values());
    }

    public void clearStore(){
        store.clear();
    }
}
