package hello2.hello.Spring2.controller;


import hello2.hello.Spring2.domain.Member;
import hello2.hello.Spring2.service.MemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

/*annotation을 통해, spring이 뜰때 controller객체를 생성함*/
@Controller
public class MemberController {
    /*spring이 container에 있는 memberservice를 연결 시켜줌 */
    @Autowired
    public MemberController(MemberService memberService) {
        this.memberService = memberService;
    }

    /*하나를 생성하고, 공용으로 쓰이게 */
    private final MemberService memberService;

    /*GetMapping: 조회할때 사용*/
    @GetMapping("members/new")
    public String createForm() {
        return "members/createMemberForm";
    }

    /*PostMapping: data를 form에 넣어서 전달할때 사용 */
    @PostMapping("/members/new")
    public String create(MemberForm form) {
        Member member = new Member();
        member.setName(form.getName());
        /*form.getName(): 입력한 text*/

        memberService.join(member);
        /*가입*/
        return "redirect:/";
    }

    @GetMapping("/members")
    public String list(Model model)  {
        List<Member> members = memberService.findMembers();
        /*list 형태로 모든 회원 저장*/
        model.addAttribute("members", members);
        return "members/memberList";
    }
}
