package hello2.hello.Spring2.repository;

import hello2.hello.Spring2.domain.Member;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface SpringDataJpaMemberRepository extends JpaRepository<Member, Long>, MemberRepository {
    @Override
    Optional<Member> findByName(String name);
    //select m from Member m where m.name =?라고 번역을 해줌
}
