package hello2.hello.Spring2.aop;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;


@Aspect
@Component //Bean에 등록하기 위해서
public class TimeTraceAop {
    @Around("execution(* hello2.hello.Spring2..*(..))")
    //어디에다가 적용할지 타겟팅
    public Object execute(ProceedingJoinPoint joinPoint) throws Throwable {

        long start = System.currentTimeMillis();
        System.out.println("START: "+joinPoint.toString());
        try {
            return joinPoint.proceed();//다음 메소드로 진행(프록시)
        } finally {
            long finish = System.currentTimeMillis();
            long timeMs = finish - start;
            System.out.println("END: " + joinPoint.toString() + " "+timeMs+"ms");
        }
    }

}
