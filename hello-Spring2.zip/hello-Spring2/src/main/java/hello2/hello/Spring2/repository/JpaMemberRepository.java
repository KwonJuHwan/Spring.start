package hello2.hello.Spring2.repository;

import hello2.hello.Spring2.domain.Member;
import org.hibernate.boot.model.source.internal.hbm.XmlElementMetadata;

import javax.persistence.EntityManager;
import java.util.List;
import java.util.Optional;

public class JpaMemberRepository implements MemberRepository{

    /*외부 라이브러리(JPA)를 가져왔기때문에,
    spring boot가 자동으로 entitymanager 생성*/
    private final EntityManager em;

    public JpaMemberRepository(EntityManager em) {
        this.em = em;
    }

    @Override
    public Member save(Member member) {
        em.persist(member);
        return member;
    }

    @Override
    public Optional<Member> findById(Long id) {
        Member member= em.find(Member.class, id);
        return Optional.ofNullable(member);
    }
    /*primary key값이 아닌 다른 값으로 find할땐, createQuery를 이용해야함*/
    @Override
    public Optional<Member> findByName(String name) {
        List<Member> result = em.createQuery("select m from Member m where m.name = :name", Member.class)
                .setParameter("name", name)
                .getResultList();
        return result.stream().findAny();
    }

    @Override
    public List<Member> findAll() {
        return em.createQuery("select m from Member m",Member.class)
                .getResultList();
    }
}
