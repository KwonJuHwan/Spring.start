package hello2.hello.Spring2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/*이 앱을 가진 패키지들만 컴포넌트 스캔을 해줌 */
@SpringBootApplication
public class HelloSpring2Application {
	public static void  main(String[] args) {
		SpringApplication.run(HelloSpring2Application.class, args);
	}

}
